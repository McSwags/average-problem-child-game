# average-problem-child-game

![image](https://github.com/McSwags/average-problem-child-game/assets/119352195/5a2dd517-9e26-406b-9726-6f962d3e3aaa)

<h1>Polish</h1>
<ul>
  <li>Save files exist</li>
  <li>Shader</li>
  <li>Fixed color changing sky</li>
  <li>all thats left is enemy AI and we have a functioning game?</li>
</ul>
<h2>CODY! We need these sprites (please and thank you :)</h2>
<ul>
  <li>Spike</li>
  <li>Checkpoint</li>
  <li>Nasty (the landed slimeballs)</li>
  <li>Pojectile</li>
</ul>
